Public repository source snapshots, not a runnable data backup.
Run 1: 7901618f5bb79faab75c5ed98855b97dac3fe493
Run 2: 38597025821c4efad18d20171f79e894cb988daf
Run 2 stages 6-8 are incomplete. The run2 README still says not pushed; its STATUS.md and published branch take precedence.
No secrets, .git, raw corpus, database binary or full intermediate dataset included.
